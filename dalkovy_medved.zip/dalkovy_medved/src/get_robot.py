import rpyc


def get_robot(ip):
    robot = rpyc.classic.connect(ip)
    motor_module = robot.modules["ev3dev2.motor"]

    return motor_module.MoveTank(motor_module.OUTPUT_B, motor_module.OUTPUT_A)
